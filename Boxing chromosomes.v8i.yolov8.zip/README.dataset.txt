# Boxing chromosomes > 2025-11-18 7:23pm
https://universe.roboflow.com/extraction-chromosomes/boxing-chromosomes-ppulh

Provided by a Roboflow user
License: CC BY 4.0

